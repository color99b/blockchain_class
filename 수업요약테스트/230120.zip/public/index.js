document.getElementsByClassName("box")[0].onclick = function () {
  alert("클릭했다.");
};
